//
//  iOSLocationExtension.h
//  iOSLocationExtension
//
//  Created by Elisabeth Bakken on 30/03/16.
//  Copyright © 2016 KjeMar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FlashRunTimeExtensions.h"

@interface iOSLocationExtension : NSObject

@end

void iOSLocationExtensionContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet);
void iOSLocationExtensionContextFinalizer(FREContext ctx);

void iOSLocationExtensionExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet);
void iOSLocationExtensionExtFinalizer(void* extData);