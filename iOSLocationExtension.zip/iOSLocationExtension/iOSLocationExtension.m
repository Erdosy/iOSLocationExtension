//
//  iOSLocationExtension.m
//  iOSLocationExtension
//
//  Created by Elisabeth Bakken on 30/03/16.
//  Copyright © 2016 KjeMar. All rights reserved.
//

#import "iOSLocationExtension.h"
#import "FlashRunTimeExtensions.h"

@implementation iOSLocationExtension

@end

NSString *notImplemented = @"This function is not yet implemented";


FREContext extCtx;

void dispatchEvent(NSString* const eventCode, NSString* const eventLevel) {
    if(extCtx == NULL) {
        return;
    }
    FREDispatchStatusEventAsync(extCtx, (uint8_t*) [eventCode UTF8String], (uint8_t*) [eventLevel UTF8String]);
}

FREObject startGPSListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        NSString *event = @"GPS";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}

FREObject startBeaconListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    
    @autoreleasepool {
        NSString *event = @"Beacon";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}

FREObject checkBeacons(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        NSString *event = @"Beacon";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}

FREObject stopBeaconListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        NSString *event = @"Beacon";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}

FREObject startWifiListening(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[]) {
    @autoreleasepool {
        NSString *event = @"Wifi";
        dispatchEvent(event, notImplemented);
    }
    return nil;
}


void iOSLocationExtensionContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet)
{
    
    *numFunctionsToTest = 5;
    FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * (*numFunctionsToTest));
    
    func[0].name = (const uint8_t*) "ffiStartGPSListening";
    func[0].functionData = NULL;
    func[0].function = &startGPSListening;
    
    func[1].name = (const uint8_t*) "ffiStartBeaconListening";
    func[1].functionData = NULL;
    func[1].function = &startBeaconListening;
    
    func[2].name = (const uint8_t*) "ffiCheckBeacons";
    func[2].functionData = NULL;
    func[2].function = &checkBeacons;
    
    func[3].name = (const uint8_t*) "ffiStopBeaconListening";
    func[3].functionData = NULL;
    func[3].function = &stopBeaconListening;
    
    func[4].name = (const uint8_t*) "ffiStartWifiListening";
    func[4].functionData = NULL;
    func[4].function = &startWifiListening;
    
    *functionsToSet = func;
    
}

void iOSLocationExtensionExtInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet)
{
    *extDataToSet = NULL;
    *ctxInitializerToSet = &iOSLocationExtensionContextInitializer;
    *ctxFinalizerToSet = &iOSLocationExtensionContextFinalizer;
}

void iOSLocationExtensionExtFinalizer(void* extData)
{
}
void iOSLocationExtensionContextFinalizer(FREContext ctx)
{
}